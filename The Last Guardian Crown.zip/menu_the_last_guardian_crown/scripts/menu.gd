extends Control

const CENA_DO_JOGO:="res://scenes/test_level.tscn"
const CAMINHO_DA_FONTE:="res://fonts/PixelDigivolve.otf"
const TAMANHO_DA_COROA:=160.0
const COR_DOURADA:=Color(1.0,0.85,0.3)

const LISTA_DE_CONTROLES:=[
	["WASD","Mover"],
	["ESPACO","Pular"],
	["MOUSE ESQUERDO","Atacar"],
	["E","Interagir"],
	["TAB","Ataque especial"],
	["R","Reviver"],
	["ESC","Pausar"],
]

var botao_jogar:Button
var botao_fechar:Button
var painel_de_controles:Control
var texto_de_aviso:Label
var som_ao_passar_o_mouse:=AudioStreamPlayer.new()
var som_ao_clicar:=AudioStreamPlayer.new()
var sons_liberados:=false


func _ready()->void:
	get_tree().paused=false
	set_anchors_preset(Control.PRESET_FULL_RECT)

	aplicar_fonte()
	preparar_sons()
	criar_fundo()

	var coluna:=criar_coluna_central()
	coluna.add_child(criar_coroa())
	coluna.add_child(criar_titulo())
	botao_jogar=criar_botao("Jogar",ao_clicar_em_jogar,coluna)
	criar_botao("Controles",abrir_painel_de_controles,coluna)
	criar_botao("Sair",ao_clicar_em_sair,coluna)
	texto_de_aviso=Label.new()
	texto_de_aviso.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	coluna.add_child(texto_de_aviso)

	criar_creditos()
	criar_painel_de_controles()

	botao_jogar.grab_focus()
	sons_liberados=true


func _unhandled_input(evento:InputEvent)->void:
	if painel_de_controles.visible and evento.is_action_pressed("ui_cancel"):
		fechar_painel_de_controles()


func aplicar_fonte()->void:
	var fonte:=load(CAMINHO_DA_FONTE)as FontFile
	if fonte==null:
		push_warning("Fonte nao encontrada: "+CAMINHO_DA_FONTE)
		return
	fonte.antialiasing=TextServer.FONT_ANTIALIASING_NONE
	fonte.subpixel_positioning=TextServer.SUBPIXEL_POSITIONING_DISABLED
	var tema:=Theme.new()
	tema.default_font=fonte
	tema.default_font_size=24
	theme=tema


func criar_fundo()->void:
	var fundo:=ColorRect.new()
	fundo.color=Color(0.08,0.07,0.15)
	fundo.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(fundo)


func criar_coluna_central()->VBoxContainer:
	var centro:=CenterContainer.new()
	centro.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(centro)

	var coluna:=VBoxContainer.new()
	coluna.add_theme_constant_override("separation",14)
	centro.add_child(coluna)
	return coluna


func criar_titulo()->Label:
	var titulo:=Label.new()
	titulo.text="THE LAST GUARDIAN CROWN"
	titulo.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	titulo.add_theme_font_size_override("font_size",48)
	titulo.add_theme_color_override("font_color",COR_DOURADA)
	return titulo


func criar_coroa()->Control:
	var area:=Control.new()
	area.custom_minimum_size=Vector2(TAMANHO_DA_COROA+80.0,TAMANHO_DA_COROA+30.0)
	area.size_flags_horizontal=Control.SIZE_SHRINK_CENTER

	criar_aura(area)
	criar_imagem_da_coroa(area)
	return area


func criar_aura(area:Control)->void:
	var quadradinho:=Image.create(2,2,false,Image.FORMAT_RGBA8)
	quadradinho.fill(Color.WHITE)

	var aura:=CPUParticles2D.new()
	aura.texture=ImageTexture.create_from_image(quadradinho)
	aura.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	aura.position=Vector2(area.custom_minimum_size.x/2.0,TAMANHO_DA_COROA*0.55)
	aura.amount=36
	aura.lifetime=1.8
	aura.preprocess=2.0
	aura.emission_shape=CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	aura.emission_rect_extents=Vector2(TAMANHO_DA_COROA*0.38,6.0)
	aura.direction=Vector2(0,-1)
	aura.spread=18.0
	aura.gravity=Vector2.ZERO
	aura.initial_velocity_min=18.0
	aura.initial_velocity_max=50.0
	aura.scale_amount_min=2.0
	aura.scale_amount_max=4.0
	aura.color_ramp=criar_cores_da_aura()
	area.add_child(aura)


func criar_cores_da_aura()->Gradient:
	var cores:=Gradient.new()
	cores.offsets=PackedFloat32Array([0.0,0.2,0.7,1.0])
	cores.colors=PackedColorArray([
		Color(1.0,0.85,0.3,0.0),
		Color(1.0,0.9,0.45,0.95),
		Color(1.0,0.65,0.15,0.6),
		Color(1.0,0.4,0.1,0.0),
	])
	return cores


func criar_imagem_da_coroa(area:Control)->void:
	var textura:=load("res://sprites/crown.png")as Texture2D
	if textura==null:
		return

	var coroa:=TextureRect.new()
	coroa.texture=textura
	coroa.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	coroa.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	coroa.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	coroa.size=Vector2(TAMANHO_DA_COROA,TAMANHO_DA_COROA)
	coroa.position=Vector2((area.custom_minimum_size.x-TAMANHO_DA_COROA)/2.0,20.0)
	area.add_child(coroa)

	fazer_coroa_flutuar(coroa)
	fazer_coroa_brilhar(coroa)


func fazer_coroa_flutuar(coroa:TextureRect)->void:
	var movimento:=create_tween().set_loops()
	movimento.tween_property(coroa,"position:y",12.0,1.2).set_trans(Tween.TRANS_SINE)
	movimento.tween_property(coroa,"position:y",20.0,1.2).set_trans(Tween.TRANS_SINE)


func fazer_coroa_brilhar(coroa:TextureRect)->void:
	var brilho:=create_tween().set_loops()
	brilho.tween_property(coroa,"modulate",Color(1.25,1.15,0.85),0.9)
	brilho.tween_property(coroa,"modulate",Color.WHITE,0.9)


func criar_botao(texto:String,ao_clicar:Callable,pai:Node)->Button:
	var botao:=Button.new()
	botao.text=texto
	botao.custom_minimum_size=Vector2(260,52)
	botao.size_flags_horizontal=Control.SIZE_SHRINK_CENTER
	botao.pressed.connect(ao_clicar)
	botao.pressed.connect(tocar_som_de_clique)
	botao.mouse_entered.connect(tocar_som_de_passar_o_mouse)
	botao.focus_entered.connect(ao_receber_foco.bind(botao))
	pai.add_child(botao)
	return botao


func ao_receber_foco(botao:Button)->void:
	if not botao.is_hovered():
		tocar_som_de_passar_o_mouse()


func criar_painel_de_controles()->void:
	painel_de_controles=Control.new()
	painel_de_controles.set_anchors_preset(Control.PRESET_FULL_RECT)
	painel_de_controles.visible=false
	add_child(painel_de_controles)

	var escurecer_tela:=ColorRect.new()
	escurecer_tela.color=Color(0,0,0,0.75)
	escurecer_tela.set_anchors_preset(Control.PRESET_FULL_RECT)
	painel_de_controles.add_child(escurecer_tela)

	var centro:=CenterContainer.new()
	centro.set_anchors_preset(Control.PRESET_FULL_RECT)
	painel_de_controles.add_child(centro)

	var caixa:=PanelContainer.new()
	centro.add_child(caixa)

	var conteudo:=VBoxContainer.new()
	conteudo.add_theme_constant_override("separation",18)
	caixa.add_child(conteudo)

	var titulo:=Label.new()
	titulo.text="CONTROLES"
	titulo.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	titulo.add_theme_font_size_override("font_size",36)
	titulo.add_theme_color_override("font_color",COR_DOURADA)
	conteudo.add_child(titulo)

	conteudo.add_child(criar_tabela_de_controles())
	botao_fechar=criar_botao("Fechar",fechar_painel_de_controles,conteudo)


func criar_tabela_de_controles()->GridContainer:
	var tabela:=GridContainer.new()
	tabela.columns=2
	tabela.add_theme_constant_override("h_separation",40)
	tabela.add_theme_constant_override("v_separation",8)

	for linha in LISTA_DE_CONTROLES:
		var tecla:=Label.new()
		tecla.text=linha[0]
		tecla.add_theme_color_override("font_color",COR_DOURADA)
		tabela.add_child(tecla)

		var acao:=Label.new()
		acao.text=linha[1]
		tabela.add_child(acao)
	return tabela


func abrir_painel_de_controles()->void:
	painel_de_controles.visible=true
	botao_fechar.grab_focus()


func fechar_painel_de_controles()->void:
	painel_de_controles.visible=false
	botao_jogar.grab_focus()


func criar_creditos()->void:
	var credito_da_fonte:=criar_texto_de_credito("Fonte: Pixel Digivolve - Pixel Sagas")
	credito_da_fonte.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT,Control.PRESET_MODE_MINSIZE,12)

	var credito_dos_autores:=criar_texto_de_credito("Por: Afonso Victor e Paulo Barone")
	credito_dos_autores.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT,Control.PRESET_MODE_MINSIZE,12)


func criar_texto_de_credito(texto:String)->Label:
	var credito:=Label.new()
	credito.text=texto
	credito.add_theme_font_size_override("font_size",14)
	credito.add_theme_color_override("font_color",Color(1,1,1,0.6))
	add_child(credito)
	return credito


func preparar_sons()->void:
	som_ao_passar_o_mouse.stream=load("res://sounds/hover.wav")as AudioStream
	som_ao_clicar.stream=load("res://sounds/click.wav")as AudioStream
	add_child(som_ao_passar_o_mouse)
	add_child(som_ao_clicar)


func tocar_som_de_passar_o_mouse()->void:
	if sons_liberados:
		som_ao_passar_o_mouse.play()


func tocar_som_de_clique()->void:
	som_ao_clicar.play()


func ao_clicar_em_jogar()->void:
	if ResourceLoader.exists(CENA_DO_JOGO):
		get_tree().change_scene_to_file(CENA_DO_JOGO)
	else:
		texto_de_aviso.text="O jogo ainda nao foi adicionado."


func ao_clicar_em_sair()->void:
	get_tree().quit()
